package simulator;

import support.Entity;

public abstract class Node implements Entity {
	protected Address addr;
	
	@Override
	public String getName() {
		return addr.toString();
	}
	
	@Override
	public long getAddress() {
		return addr.getAddress();
	}
}
