package support;

import simulator.Address;
import simulator.Endhost;

public interface TopoFace {
	public Endhost getHost(Address addr);
}
